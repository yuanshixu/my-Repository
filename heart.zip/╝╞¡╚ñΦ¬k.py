#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import tkinter as tk

def heart():
    df = pd.read_csv("heart.csv")
# print(df.head(5))
    df = df.iloc[np.random.permutation(len(df))]
# print(df.head(5))

    valid_data = df.iloc[0:int(len(df)/5)].to_numpy()
    train_data = df.iloc[int(len(df)/5):].to_numpy()
# print(train_data[0:5])
    train_X = train_data[:,0:13]
    train_y = train_data[:,13]
    valid_X = valid_data[:,0:13]
    valid_y = valid_data[:,13]
# print(train_X[0:5])
# print(train_y[0:5])
    pca = PCA(n_components=4)
    pca.fit(train_X)
# print(pca.explained_variance_ratio_)
# print(sum(pca.explained_variance_ratio_))
# print(pca.singular_values_)
    PCA_train_X = pca.transform(train_X)
    PCA_valid_X = pca.transform(valid_X)

    clf = make_pipeline(StandardScaler(), SVC(gamma='auto'))
    clf.fit(train_X, train_y)
    pred = clf.predict(valid_X)

    acc = 0
    for p , label in zip(pred, valid_y):
        if p == label:
            acc += 1
    print("Acc :", acc / len(pred))

#query = input().split()

    query = []

    a = text_1.get("1.0","end")
    a = float(a)
    a1 = text_2.get("1.0","end")
    a1 = float(a1)
    a2 = text_3.get("1.0","end")
    a2 = float(a2)
    a3 = text_4.get("1.0","end")
    a3 = float(a3)
    a4 = text_5.get("1.0","end")
    a4 = float(a4)
    a5 = text_6.get("1.0","end")
    a5 = float(a5)
    a6 = text_7.get("1.0","end")
    a6 = float(a6)
    a7 = text_8.get("1.0","end")
    a7 = float(a7)
    a8 = text_9.get("1.0","end")
    a8 = float(a8)
    a9 = text_10.get("1.0","end")
    a9 = float(a9)
    a10 = text_11.get("1.0","end")
    a10 = float(a10)
    a11 = text_12.get("1.0","end")
    a11 = float(a11)
    a12 = text_13.get("1.0","end")
    a12 = float(a12)
    query.append(a)
    query.append(a1)
    query.append(a2)
    query.append(a3)
    query.append(a4)
    query.append(a5)
    query.append(a6)
    query.append(a7)
    query.append(a8)
    query.append(a9)
    query.append(a10)
    query.append(a11)
    query.append(a12)
    query = np.array(query)


#query = np.array([float(q) for q in query])
    pred = clf.predict([query])
#print(pred[0])
    if pred[0] == 1.0:
        result = f'結果為高風險'
        result_label.configure(text=result)
    else:
        result = f'結果為低風險'
        result_label.configure(text=result)


# In[14]:


win = tk.Tk()
win.title('心臟病預測分析系統')
win.geometry('600x520') # width x height

#label
label_1 = tk.Label(win, text='準備好開始檢測心臟病風險了嗎?', font=('Arial',16))
label_1.grid(row=0, column=0, columnspan = 8, padx=20, pady=40)
label_2 = tk.Label(win, text='以下13項數據請依序填入,並以空白鍵隔開.', font=('Arial',12))
label_2.grid(row=1, column=0, columnspan = 8, padx=20, pady=0)
label_3 = tk.Label(win, text='age,sex,cp,trtbps,chol,fbs,restecg,thalachh,exng,oldpeak,slp,caa,thall', font=('Arial',10))
label_3.grid(row=2, column=0, columnspan = 8, padx=20, pady=10)
#Test
# text_1 = tk.Text(win, width=50, height=2) 
# text_1.grid(row=3, column=0, padx=15, pady=10)
#第一行
label_4 = tk.Label(win, text='age', font=('Arial',10))
label_4.grid(row=3, column=0, sticky='E', padx=10)
text_1 = tk.Text(win, width=10, height=1) 
text_1.grid(row=3, column=1, pady=10, sticky='w')

label_5 = tk.Label(win, text='sex', font=('Arial',10))
label_5.grid(row=3, column=2, sticky='E', padx=10)
text_2 = tk.Text(win, width=10, height=1) 
text_2.grid(row=3, column=3, pady=10, sticky='w')

label_6 = tk.Label(win, text='cp', font=('Arial',10))
label_6.grid(row=3, column=4, sticky='E', padx=10)
text_3 = tk.Text(win, width=10, height=1) 
text_3.grid(row=3, column=5, pady=10, sticky='w')

label_7 = tk.Label(win, text='trtbps', font=('Arial',10))
label_7.grid(row=3, column=6, sticky='E', padx=10)
text_4 = tk.Text(win, width=10, height=1) 
text_4.grid(row=3, column=7, pady=10, sticky='w')

#第二行
label_8 = tk.Label(win, text='chol', font=('Arial',10))
label_8.grid(row=4, column=0, sticky='E', padx=10)
text_5 = tk.Text(win, width=10, height=1) 
text_5.grid(row=4, column=1, pady=10, sticky='w')

label_9 = tk.Label(win, text='fbs', font=('Arial',10))
label_9.grid(row=4, column=2, sticky='E', padx=10)
text_6 = tk.Text(win, width=10, height=1) 
text_6.grid(row=4, column=3, pady=10, sticky='w')

label_10 = tk.Label(win, text='restecg', font=('Arial',10))
label_10.grid(row=4, column=4, sticky='E', padx=10)
text_7 = tk.Text(win, width=10, height=1) 
text_7.grid(row=4, column=5, pady=10, sticky='w')

label_11 = tk.Label(win, text='thalachh', font=('Arial',10))
label_11.grid(row=4, column=6, sticky='E', padx=10)
text_8 = tk.Text(win, width=10, height=1) 
text_8.grid(row=4, column=7, pady=10, sticky='w')

#第3行
label_12 = tk.Label(win, text='exng', font=('Arial',10))
label_12.grid(row=5, column=0, sticky='E', padx=10)
text_9 = tk.Text(win, width=10, height=1) 
text_9.grid(row=5, column=1, pady=10, sticky='w')

label_13 = tk.Label(win, text='oldpeak', font=('Arial',10))
label_13.grid(row=5, column=2, sticky='E', padx=10)
text_10 = tk.Text(win, width=10, height=1) 
text_10.grid(row=5, column=3, pady=10, sticky='w')

label_14 = tk.Label(win, text='slp', font=('Arial',10))
label_14.grid(row=5, column=4, sticky='E', padx=10)
text_11 = tk.Text(win, width=10, height=1) 
text_11.grid(row=5, column=5, pady=10, sticky='w')

label_15 = tk.Label(win, text='caa', font=('Arial',10))
label_15.grid(row=5, column=6, sticky='E', padx=10)
text_12 = tk.Text(win, width=10, height=1) 
text_12.grid(row=5, column=7, pady=10, sticky='w')

#第4行
label_16 = tk.Label(win, text='thall', font=('Arial',10))
label_16.grid(row=6, column=0, sticky='E', padx=10)
text_13 = tk.Text(win, width=10, height=1) 
text_13.grid(row=6, column=1, pady=10, sticky='w')


#Button
button = tk.Button(win, text='確認輸入', font=('Arial',12), width = 30, height = 2, command = heart)
button.grid(row=7, column=0, columnspan = 8, padx=15, pady=15)
#chol,fbs,restecg,thalachh,exng,oldpeak,slp,caa,thall

result_label = tk.Label(win, font = ('Arial', 30), justify = "left", fg = 'red')
result_label.grid(row = 8, column = 0, columnspan = 8, padx = 25, pady=15)

win.mainloop()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[79]:





# In[ ]:




